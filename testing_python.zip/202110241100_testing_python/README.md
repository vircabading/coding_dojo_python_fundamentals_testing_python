# Testing Python Read Me

This is an assignment for Coding Dojo > Pytho Stack > Python > Fundamentals > Testing Python.
Here, we are running a python file to see the output in a bash window